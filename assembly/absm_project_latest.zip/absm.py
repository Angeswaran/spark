import io
import configparser
import sys
import json
import os
from audit.Custom_Logger import getLogger
from audit.enrichment.enrich import enrich

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr, current_timestamp, lit, concat_ws, coalesce


def generate_audit_status(tgt_df,src_controls_list):
    #print(src_controls_list)
    src_controls_list.sort(key=lambda x: int(x['order']))
    audit_status = "\"case when "
    audit_status_code = "\"case when "
    i=0
    for condition in src_controls_list:
        if i ==0:
            audit_status =  audit_status + condition['condition'] + " then \'" + condition['results']['audit_status'] + "\' \""
            audit_status_code = audit_status_code + condition['condition'] + " then \'" + condition['results']['audit_status_code'] + "\' \""
        else:
            audit_status = audit_status + " + \"when " + condition['condition'] + " then \'" + condition['results']['audit_status'] + "\' \""
            audit_status_code = audit_status_code + " + \"when " + condition['condition'] + " then \'" + condition['results']['audit_status_code'] + "\' \""
        i=i+1
    audit_status = audit_status + " + \"else 'T' end\""
    audit_status_code = audit_status_code + " + \"else 'E0078' end\""
    tgt_df_audit_status = tgt_df.withColumn("audit_status", expr(eval(audit_status)))
    tgt_df_audit_status_reason_code = tgt_df_audit_status.withColumn("audit_reason_code", expr(eval(audit_status_code)))
    return tgt_df_audit_status_reason_code


def target_column_mapped(df, src_input, auditType):
    src_tbl_name=src_input['details']['database']+'.'+src_input['details']['source']
    src_tbl_ident_field="-".join(src_input['details']['primary_key'])

    target_table=df.withColumn("source_table_name",lit(src_tbl_name)) \
        .withColumn("source_table_identifier_field",lit(src_tbl_ident_field )) \
        .withColumn("source_table_identifier", concat_ws("-",*df.select(src_input['details']['primary_key']))) \
        .withColumn("audit_type", lit(auditType)) \
        .withColumn("profile_identifier", df["abbott_customer_id"]) \
        .withColumn("profile_abs_code", df["primary_customer_abs"]) \
        .withColumn("associated_profile_identifier", df["assoc_abbott_customer_id"]) \
        .withColumn("associated_profile_abs_code", df["assoc_customer_abs"]) \
        .withColumn("profile_prescriber_status", df["prescriber_status"]) \
        .withColumn("associated_profile_prescriber_status", df["assoc_prescriber_status"]) \
        .withColumn("profile_degree_code", df["primary_degree"]) \
        .withColumn("associated_profile_degree_code", df["assoc_primary_degree"]) \
        .withColumn("profile_role_name", df["role_abv__c"]) \
        .withColumn("ref_version_number", df["version_id"]) \
        .withColumn("ref_abs_code", df["apps_primary_abs"]) \
        .withColumn("ref_associated_abs_code", df["abv_assoc_best_specialty_code"]) \
        .withColumn("product_name", df["irep_product_name"]) \
        .withColumn("approved_brand_name", coalesce(df["apps_approved_product"],df["approved_brand_specialty"])) \
        .withColumn("activity_datetime", df["email_sent_date_vod__c"]) \
        .withColumn("sales_force_code", df["salesforce_abv__c"]) \
        .withColumn("territory_number", df["territory_vod__c"]) \
        .withColumn("upi_number", df["upi_number"]) \
        .withColumn("employee_number", df["employee_number"]) \
        .withColumn("src_system_name", df["src_system_name"])
    tgt_df = target_table.select("source_table_name","source_table_identifier_field","source_table_identifier","audit_type","profile_identifier", "profile_abs_code",
                                 "associated_profile_identifier","associated_profile_abs_code", "profile_prescriber_status","associated_profile_prescriber_status",
                                 "profile_degree_code","associated_profile_degree_code",
                                 "profile_role_name", "ref_version_number","ref_abs_code", "ref_associated_abs_code", "product_name", "approved_brand_name",
                                 "activity_datetime", "sales_force_code", "territory_number", "upi_number",
                                 "employee_number", "audit_status","audit_reason_code","src_system_name")
    return (tgt_df)





def load_json(file):
    with open(file) as config_file:
        conf = json.load(config_file)
    return conf

def read_data_files(spark):
    src_df = spark.read.csv(
        'file:///C:\\Users\\724027\\OneDrive - Cognizant\\17. AbbVie\\4. ABS\\Email_HCP_ABS\\irep_sent_email_pipe_sep_dev.csv', \
        header=True, \
        inferSchema=True, \
        sep='|')
    # src_df.printSchema()
    src_df.createOrReplaceTempView('irep_sent_email_vod__c_vw')
    hauf = spark.read.csv(
        'file:///C:\\Users\\724027\\OneDrive - Cognizant\\17. AbbVie\\4. ABS\\sample files\\apps_universe_thin_vw.csv', \
        header=True, \
        inferSchema=True)
    hauf.createOrReplaceTempView('apps_universe_thin_vw')

    dbsm = spark.read.csv(
        'file:///C:\\Users\\724027\\OneDrive - Cognizant\\17. AbbVie\\4. ABS\\sample files\\hcp360_product_brand_spc_mtrx_xref_vw.csv', \
        header=True, \
        inferSchema=True)
    dbsm.createOrReplaceTempView('hcp360_product_brand_spc_mtrx_xref_vw')

    version = spark.read.csv(
        'file:///C:\\Users\\724027\\OneDrive - Cognizant\\17. AbbVie\\4. ABS\\sample files\\version_vw.csv', \
        header=True, \
        inferSchema=True)
    version.createOrReplaceTempView('version_vw')

    customer = spark.read.csv(
        'file:///C:\\Users\\724027\\OneDrive - Cognizant\\17. AbbVie\\4. ABS\\sample files\\customer_vw.csv', \
        header=True, \
        inferSchema=True)
    customer.createOrReplaceTempView('customer_vw')

    user = spark.read.csv(
        'file:///C:\\Users\\724027\\OneDrive - Cognizant\\17. AbbVie\\4. ABS\\sample files\\user_vw.csv', \
        header=True, \
        inferSchema=True)
    user.createOrReplaceTempView('irep_user_vw')

    employee = spark.read.csv(
        'file:///C:\\Users\\724027\\OneDrive - Cognizant\\17. AbbVie\\4. ABS\\sample files\\employee_vw.csv', \
        header=True, \
        inferSchema=True)
    employee.createOrReplaceTempView('employee_vw')

    account = spark.read.csv(
        'file:///C:\\Users\\724027\\OneDrive - Cognizant\\17. AbbVie\\4. ABS\\sample files\\irep_account_vw.csv', \
        header=True, \
        inferSchema=True)
    account.createOrReplaceTempView('irep_account_vw')


def execute_join(spark, jQuery, joinDF):
    joinDF=spark.sql(jQuery)
    LOGGER.info("executed join with query: {}".format((jQuery)))
    return joinDF


def coalcase(df):
    cdf=df.withColumn("prescriber_status", concat_ws('~',coalesce(df["prescriber_status"],lit('')),coalesce(df["primary_degree"],lit('')))) \
          .withColumn("assoc_prescriber_status", concat_ws('~',coalesce(df["assoc_prescriber_status"],lit('')),coalesce(df["assoc_primary_degree"],lit(''))))\
          .withColumn("presc_app_status", expr("case when prescriber_status IN ('PRESCRIBERS','Non-Prescriber with ABS','HCP Pending Verification') then 'PRESCRIBER'" +
                                        "when prescriber_status IN ('NONPRESCRIBERS') then 'NON_PRESCRIBER'" +
                                        "else 'OTHER' end"))\
          .withColumn("assoc_presc_app_status", expr("case when assoc_prescriber_status IN ('PRESCRIBERS','Non-Prescriber with ABS','HCP Pending Verification') then 'PRESCRIBER'" +
                                        "when assoc_prescriber_status IN ('NONPRESCRIBERS') then 'NON_PRESCRIBER'" +
                                        "else 'OTHER' end"))

    return(cdf)

def prepare_data_frame(spark,src_prop,dim_prop,LOGGER):
    LOGGER.info("Inside prepare data frame")
    #LOGGER.info(src_prop)
    dfList=[]
    viewList=[]
    #LOGGER.info(type(src_prop))
    query=''
    print(src_prop)
    print(dim_prop)

    src_name=src_prop['name']
    auditType=src_prop['auditType']
    src_input=src_prop['input']
    src_enrichments=src_prop['enrichments']
    src_controls = src_prop['controls']
    LOGGER.info("src_name : {}\nauditType : {}\nsrc_input : {}\nsrc_enrichments : {}".format(src_name, auditType, src_input, src_enrichments))
    enriched_src_df = enrich(spark,src_name,src_input,src_enrichments,dim_prop,LOGGER)

    #coalesce & case-when in orignal sql
    LOGGER.info("Started coalesce & case-when on enriched data")
    enriched_src_df_coalesced=coalcase(enriched_src_df)

    # AUDIT STATUS
    LOGGER.info("Started audit status generation on enriched-coalesced data")
    target_df = generate_audit_status(enriched_src_df_coalesced, src_controls)

    # Target column mapping
    LOGGER.info("Started mapping of enriched-coalesced-auditted data frame with target table")
    mapped_df = target_column_mapped(target_df, src_input, auditType)
    # print(mapped_df)

    # print("Final Target Schema and data ")
    # target_view.select("audit_status", "audit_status_code").show(3)
    # target_view.printSchema()
    # target_view.show(3)

    #x,y=generate_aduit_status(enriched_src_df, src_controls)
    # print(x,y)
    # print(target_view)
    return mapped_df

if __name__=="__main__":
        dfList=[]
        spark = SparkSession.builder.appName("ABSM").getOrCreate()
        LOGGER = getLogger('ABSM')
        LOGGER.info('ABSM Started')
        #For TESTING
        # read_data_files(spark)   #creating temp view, similar hive tables
        # dim_prop = load_json('absm_dim_config.json')
        # src_prop = load_json('absm_test_config.json')

        #FOR TESTING
        # src_prop = load_json('absm_test_config.json')
        # for k in src_prop['audits'].keys():
        #     print(k)

        src_prop = load_json(sys.argv[1])
        dim_prop = load_json(sys.argv[2])

        finaldf=prepare_data_frame(spark,src_prop['audits']['iRepEmail-HCP-ABS'],dim_prop,LOGGER)

        #LOGGER.info(finaldf)
        #LOGGER.info(finaldf.printSchema())
        finaldf.show()
        finaldf_wdt=finaldf.withColumn("created_datetime",current_timestamp())

        finaldf_wdt.show()
        finaldf_wdt.write.mode('overwrite').saveAsTable('abv_hcp360_integrated_work.absmAuditTbl')
        # finaldf_wdt.write.csv('file:///absmAuditTbl',mode='overwrite',header=True)







