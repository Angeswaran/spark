import sys
from pyspark.sql.functions import expr


def create_data_frame_query(spark, query, LOGGER):
    dfName = spark.sql(query)
    LOGGER.info(dfName)
    return dfName

def create_data_frame(spark, dfName, dbName, tbName, colList, filterCond, LOGGER):
    LOGGER.info("colList={}\nLength of colList :: {}".format(colList, len(colList)))
    LOGGER.info("filterCond={}\nLength of filterCond :: {}".format(filterCond, len(filterCond)))
    # if len(colList) > 0 and len(filterCond) > 0:
    #     query = "select " + ",".join(colList) + " from " + dbName + "." + tbName + " where " + filterCond
    # elif len(colList) > 0:
    #     query = "select " + ",".join(colList) + " from " + dbName + "." + tbName
    # elif len(filterCond) > 0:
    #     query = "select * from " + dbName + "." + tbName + " where " + filterCond
    # else:
    #     query = "select * from " + dbName + "." + tbName

    #FOR TESTING
    if len(colList) > 0 and len(filterCond) > 0:
        query = "select " + ",".join(colList) + " from " + tbName + " where " + filterCond
    elif len(colList) > 0:
        query = "select " + ",".join(colList) + " from " + tbName
    elif len(filterCond) > 0:
        query = "select * from " + tbName + " where " + filterCond
    else:
        query = "select * from " + tbName

    LOGGER.info("query = {}".format(query))

    dfName = spark.sql(query)
    dfName.show(2)
    LOGGER.info(dfName)
    return dfName

def create_view(dfName, viewName, LOGGER):
    dfName.createOrReplaceTempView(viewName)
    LOGGER.info("Temp View created : {}".format(viewName))
    return viewName


def dropDup(df, tbl, LOGGER):
    clm_list=df.columns
    uninque_cols = []
    duplicate_cols = []
    for i in clm_list:
        if i in uninque_cols:
            duplicate_cols.append(i)
        else:
            uninque_cols.append(i)
    LOGGER.info("All Columns :: {}".format(clm_list))
    LOGGER.info("Unique Columns :: {}".format(uninque_cols))
    LOGGER.info("Duplicate Columns :: {}".format(duplicate_cols))
    for clm in duplicate_cols:
        df=df.drop(expr(tbl+'.'+clm))
    return df

def enrich(spark,src_name,src,enrich_list,dims,LOGGER):
    #usage
    #params : input dictionary and enrichment (list of dictionaries) and absm_dim_config
    LOGGER.info("src : {}\nenrich_list : {}\ndims : {}".format(src,enrich_list,dims))
    # cdf=Create_Data_Frame()
    src_type=str(src['type'])
    srcPK = src['details']['primary_key']
    # src_tbl=src['details']['source']
    if str.upper(src_type) == 'QUERY':
        src_query = src['details']['sql']
        src_df = create_data_frame_query(spark, src_query, LOGGER)
    elif str.upper(src_type) == 'TABLE':
        srcTbl = src['details']['source']
        srcDb = src['details']['database']
        srcColList=src['details']['fields']
        srcFilter=src['details']['filter']['sql']
        src_df=create_data_frame(spark,"src_df",srcDb,srcTbl,srcColList,srcFilter, LOGGER)
    else:
        LOGGER.error("ERROR: src_type is not known. Terminating Process....")
        sys.exit(1)

    # src_df.createOrReplaceTempView(src_tbl)
    sView=create_view(src_df,src_name, LOGGER)
    
    LOGGER.info("enrichment list : {}".format(enrich_list))
    enrich_list.sort(key=lambda x: int(x['order']))
    LOGGER.info("sorted enrichment list : {}".format(enrich_list))
    if len(enrich_list) > 0:
        for enr in enrich_list:
            enr_name = enr['name']
            enr_type = str(enr['type'])
            enr_parent = enr['details']['lookup']
            if str.upper(enr_type) == 'QUERY':
                #in case of query, there is no need to check for parent dim lookup
                LOGGER.info("enrichment type is : {}, reading sql directly".format(enr_type))
                enr_query = enr['details']['sql']
                enr_df = create_data_frame_query(spark, enr_query, LOGGER)
            elif str.upper(enr_type) == 'REFERENCE_LOOKUP':
                # parent dim lookup
                enrTbl = dims[enr_parent]['details']['source']
                enrDb = dims[enr_parent]['details']['database']

                if 'fields' in (enr['details']).keys():                     #from src enrichment details
                    enrColList = enr['details']['fields']
                elif 'fields' in (dims[enr_parent]['details']).keys():      #from dimension_config details
                    LOGGER.info("fields property not found in source for enrich table : {}, fetching from lookup dimension : {}".format(enr_name, enr_parent))
                    enrColList = dims[enr_parent]['details']['fields']
                else:                                                       #if property not present in both src enrichment and dimension_config
                    LOGGER.info("fields property neither found in source : {} and nor in lookup dimension : {}, setting it to EMPTY".format(enr_name, enr_parent))
                    enrColList=''

                if 'filter' in (enr['details']).keys():                     #from src enrichment details
                    enrFilter = enr['details']['filter']['sql']
                elif 'filter' in (dims[enr_parent]['details']).keys():      #from dimension_config details
                    LOGGER.info("filter property not found in source for enrich table : {}, fetich from lookup dimension : {}".format(enr_name, enr_parent))
                    enrFilter = dims[enr_parent]['details']['filter']['sql']
                else:                                                       #if property not present in both src enrichment and dimension_config
                    LOGGER.info("filter not found in source : {} and neither in lookup dimension : {}, setting it to EMPTY".format(enr_name, enr_parent))
                    enrFilter=''

                #FILTER HAUF DATA BASED on Verison id
                # if enrTbl == 'apps_universe_thin_vw':
                #     version_id_list_query="select distinct(version_id) from {}".format(sView)
                #     version_id_list = tuple(spark.sql(version_id_list_query).rdd.map(lambda x:x[0]).collect())
                #     LOGGER.info("version_id_list : {}".format(version_id_list))
                #     if enrFilter == '' and len(version_id_list) != 0 :
                #         enrFilter = "version_id in {}".format(version_id_list)
                #     elif len(version_id_list) != 0 :
                #         enrFilter="version_id in {} and {}".format(version_id_list, enrFilter)
                #     else:
                #         LOGGER.info("version_id list is EMPTY")
                enr_df = create_data_frame(spark, "enr_df", enrDb, enrTbl, enrColList, enrFilter, LOGGER)

            eView = create_view(enr_df, enr_name, LOGGER)

            #enrich_df=spark.sql(enr_query)
            #enrich_df.createOrReplaceTempView(enr_name)

            #Join enrichment with source
            #reading join details from src enrichment
            # NOTE: join details must be present in src enrichment.
            eJtype=enr['details']['join']['type']
            eJcond=enr['details']['join']['sql']

            jQuery = "select * from {} {} join {} on {}".format(sView, eJtype, eView, eJcond)
            LOGGER.info("join query : {}".format(jQuery))
            joinDF = spark.sql(jQuery)
            LOGGER.info("Joined data frame created :: {}".format(joinDF))

            djDF=dropDup(joinDF, eView, LOGGER)
            LOGGER.info("Joined data frame after dropping colms :: {}".format(djDF))

            sView = create_view(djDF, src_name, LOGGER)
    else:
        LOGGER.info("No enrichments to be done, returning with src_df")
        djDF = src_df
    # djDF.show()
    return djDF        
